export class ResponseFilterItems{
  data: any[];
  total_pages: number;
  current_page: number;
  page: number;
  items: number;
}
