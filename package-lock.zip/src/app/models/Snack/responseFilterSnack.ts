export class ResponseFilterSnacks {
  data: any[];
  total_pages: number;
  current_page: number;
  page: number;
  snacks: number;
}
