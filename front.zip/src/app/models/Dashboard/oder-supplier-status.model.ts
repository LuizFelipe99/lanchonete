export interface OrderSupplierStatus{
    labels: { label: string }[];
    quantity: { quantity: number }[];
    orders: { orders: number }[];
}