
export interface itemRank{
    data: any[];
    snacks: any[];
    id_item: any;
    name: any;
    rank: any;
    total: any;

}
