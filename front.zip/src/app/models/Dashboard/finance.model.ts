export interface financeDashModel{
    data: any[];
    current_month: any[];
    order_supplier: any[];
    order_snack: any[];
}

export interface financeDetailDashModel{
    data: any[];
    total_pix: number [];
    total_cash: any[];
    total_card: any[];
    labels: any [];
    quantity: any [];
    month: any [];
}