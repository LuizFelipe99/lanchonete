export interface ItemsCategoryDashboard{
    labels: { label: string }[];
    quantity: { quantity: number }[];
    categories: { categories: number }[];
}