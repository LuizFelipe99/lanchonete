export interface UserStatsDashboard{
    labels: { status: number }[];
    quantity: { quantity: number }[];
    users: { users: number }[];
}